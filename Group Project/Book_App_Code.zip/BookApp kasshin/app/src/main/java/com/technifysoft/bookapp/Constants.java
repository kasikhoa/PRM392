package com.technifysoft.bookapp;

public class Constants {

    public static final long MAX_BYTES_PDF = 50000000; //50MB
}
